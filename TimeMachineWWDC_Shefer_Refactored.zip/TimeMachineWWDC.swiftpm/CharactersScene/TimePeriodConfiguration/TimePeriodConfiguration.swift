import SwiftUI

struct TimePeriodConfiguration {
    var playerConfig: PlayerConfiguration
    var gradientColors: [Color]
    var fontColor: Color
    var yearFont: Font
    var titleFont: Font
    var systemIconName: String
    var timePeriodYear: String
    var modelId: String
}
