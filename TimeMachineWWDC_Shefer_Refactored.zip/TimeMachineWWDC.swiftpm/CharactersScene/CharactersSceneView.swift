import SwiftUI
import SwiftUIX

struct CharactersSceneView: View {
    
    @EnvironmentObject var timePeriodEnv: TimePeriodEnvironment
    
    @State private var index: Int = 0
    @State private var isCharacterStoryScenePresented: Bool = false
    @State private var isCharacterStoryConversationPresented: Bool = false
    @State private var isCharacterInterestsPresented: Bool = false
    
    @State private var typeOfPreferredSheet: SheetType = .info
    
    private var characters: [Character] {
        return timePeriodEnv.timePeriod.characters
    }
    
    private var selectedCharacter: Character {
        return characters[index]
    }
    
    var body: some View {
        ZStack {
            GradientBackgroundView(timePeriod: timePeriodEnv.timePeriod)
            VStack(spacing: 10) {
                buildNavigationPanel(character: selectedCharacter)
                    .height(150)
                    .padding()
                buildCharacterView(timePeriodCharacter: selectedCharacter)
               
            }
            .padding(.horizontal, 10)
            .padding()
        }
    }
    
    //MARK: Views
    
    @ViewBuilder
    func buildNavigationPanel(character: Character) -> some View {
        VisualEffectBlurView(blurStyle: .extraLight, vibrancyStyle: .label) { 
            HStack(spacing: 30) {
                
                Button(action: {
                    withAnimation{
                        if index > 0 {
                            index -= 1
                        }
                    }
                }, label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 30, weight: .bold))
                        .opacity(index == 0 ? 0.3 : 1)
                })
                .disabled(index == 0 ? true : false)
                Text("\(character.personalData.name) \n\(character.personalData.age) years old")
                    .bold()
                    .font(timePeriodEnv.timePeriod.timePeriodConfiguration.titleFont)
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                
                Button(action: {
                    withAnimation{
                        if index < characters.count{
                                index += 1
                        }
                    }
                }, label: {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 30, weight: .bold))
                    
                    .opacity(index == characters.count - 1 ? 0.3 : 1)
                })
                 .disabled(index == characters.count - 1 ? true : false)
            }
        }
        .mask(RoundedRectangle(cornerRadius: 30, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
        .overlay(RoundedRectangle(cornerRadius: 30, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/).stroke(lineWidth: 0.5).fill(Color.white))
        .shadow(color: Color.black.opacity(0.3), radius: 20, x: 0, y: 10)
    }
    
    @ViewBuilder
    func buildCharacterView(timePeriodCharacter: Character) -> some View {
        VisualEffectBlurView(blurStyle: .extraLight) {
            VStack {
               Image(timePeriodCharacter.personalData.photo).resizable() 
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 400)
                VStack() {
                    HStack(spacing: 30) {
                        Button(action: {
                            isCharacterStoryScenePresented.toggle()
                            typeOfPreferredSheet = .info
                        }, label: {
                            Image(systemName: "person.text.rectangle")
                            Text("About him")
                        })
                        .buttonStyle(.borderedProminent)
                        .buttonBorderShape(.capsule)
                        .tintColor(.systemBlue)
                        .controlSize(.large)
                        .sheet(isPresented: $isCharacterStoryScenePresented, content: {
                            let preferredData = typeOfPreferredSheet.getNeededContent(character: selectedCharacter)
                            CharacterStorySceneView(content: preferredData)
                                .presentationDetents([.large])
                                .presentationDragIndicator(.visible)
                        })
                        
                        .interactiveDismissDisabled(false)
                        
                        Button(action: {
                            typeOfPreferredSheet = .interests
                            isCharacterStoryScenePresented.toggle()
                            
                        }, label: {
                            Image(systemName: "sparkles")
                            Text("His passion")
                        })
                        .buttonStyle(.borderedProminent)
                        .buttonBorderShape(.capsule)
                        .tintColor(.systemPurple)
                        .controlSize(.large)
                    }
                    .padding(.top, 20)
                    Button(action: { 
                        typeOfPreferredSheet = .communication
                        isCharacterStoryScenePresented.toggle()
                    }, label: { 
                        Image(systemName: .envelope)
                        Text("Talk to him")
                    })
                    .buttonStyle(.borderedProminent)
                    .buttonBorderShape(.capsule)
                    .tintColor(.systemOrange)
                    .controlSize(.large)
                }
            }
        }
        .mask(RoundedRectangle(cornerRadius: 30, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
        .overlay(RoundedRectangle(cornerRadius: 30, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/).stroke(lineWidth: 0.5).fill(Color.white))
        .shadow(color: Color.black.opacity(0.3), radius: 20, x: 0, y: 10)
        .padding()
    }
    
    @ViewBuilder 
    func characterCardButtonView() -> some View {
        
    }
    
    @ViewBuilder 
    func characterInfoSheet() -> any View {
        sheet(isPresented: $isCharacterStoryScenePresented, content: {
            let preferredData = typeOfPreferredSheet.getNeededContent(character: selectedCharacter)
            CharacterStorySceneView(content: preferredData)
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
        })
    }
 }

struct CharactersSceneView_Previews: PreviewProvider {
    static var previews: some View {
        CharactersSceneView()
            .environmentObject(TimePeriodEnvironment())
    }
}
