import SwiftUI
import UIKit

struct SheetBody {
    var titleText: String 
    var descriptionText: String
    var iconToShow: String 
    var tintColor: Color = .systemBlue
}
