import SwiftUI

enum SheetType {
    case info, interests, communication
    
    func getNeededContent(character: Character) -> SheetBody {
        let story = character.story
        switch self {
        case .info:
            return SheetBody(titleText: character.personalData.name, descriptionText: story.information, iconToShow: "person.circle.fill")
        case .communication:
            return SheetBody(titleText: "Message", descriptionText: story.message, iconToShow: "envelope.circle.fill", tintColor: .systemOrange)
        case .interests:
            return SheetBody(titleText: "Interests", descriptionText: story.interests, iconToShow: "sparkles", tintColor: .systemPurple)
        }
    }
}
