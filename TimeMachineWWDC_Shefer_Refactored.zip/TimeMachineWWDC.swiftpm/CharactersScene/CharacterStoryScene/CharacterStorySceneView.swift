import SwiftUI

struct CharacterStorySceneView: View {
     @Environment(\.dismiss) var dismiss
    
    var content: SheetBody

    var body: some View {
        VStack(alignment: .center, spacing: 20) {
            Image(systemName: content.iconToShow)
                .font(.system(size: 80))
                .foregroundColor(content.tintColor)
            VStack(spacing: 2) {
                Text(content.titleText)
                    .bold()
                    .font(.largeTitle)
                Text(content.descriptionText)
                    .padding()
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondaryLabel)
            }
            Button(action: {
                dismiss()
            }, label: {
                Text("Close")
            })
            .tintColor(.systemBlue)
            .foregroundColor(.white)
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .buttonBorderShape(.capsule)
        }
    }
    
}

struct CharacterStorySceneView_PreviewProvider: PreviewProvider {
    static var previews: some View {
        CharacterStorySceneView(content: .init(titleText: "", descriptionText: "", iconToShow: "", tintColor: .systemBlue))
            .environment(\.colorScheme, .light)
    }
}
