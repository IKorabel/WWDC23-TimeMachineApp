import SwiftUI

struct PlayerConfiguration {
    var soundCarrierModelIdentifier: String
    var activationSound: String
    var songs: [TimePeriodPlayerContent]
}
