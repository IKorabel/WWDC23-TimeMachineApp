import SwiftUI
import SceneKit
import SwiftUIX

struct TimePeriodItemView: View {
    var modelIdentifier: String
    
    var body: some View {
        VisualEffectBlurView(blurStyle: .systemThinMaterialDark, vibrancyStyle: .none) { 
            CustomSceneView(modelName: modelIdentifier)
                .frame(width: 400, height: 350)
                .onAppear(perform: {
                    print("modelID: \(modelIdentifier)")
                })
        }
        .frame(width: 400, height: 400)
        .mask(RoundedRectangle(cornerRadius: 30, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
        .overlay(RoundedRectangle(cornerRadius: 30, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/).stroke(lineWidth: 0.5).fill(Color.clear))
        .shadow(color: Color.black.opacity(0.3), radius: 20, x: 0, y: 10)
        .padding()
    }
    
}
