import SwiftUI
import SwiftUIX
import UIKit
import SpriteKit

struct TimePeriodItemsSceneView: View {
    
    @EnvironmentObject var timePeriodEnv: TimePeriodEnvironment
    
    @State private var isBottomSheetPresented: Bool = false
    @State private var index = 0
    
    private var sceneName: String {
        timePeriodItems[index].modelIdentifier
    }
    
    private var timePeriodItems: [TimePeriodItem] {
        timePeriodEnv.timePeriod.timePeriodItems
    }
    
    var body: some View {
        ZStack {
            GradientBackgroundView(timePeriod: timePeriodEnv.timePeriod)
            VStack {
                TimePeriodItemView(modelIdentifier: sceneName)
                VisualEffectBlurView(blurStyle: .systemMaterialLight, vibrancyStyle: .label) {
                    VStack() {
                        timePeriodNavigationButtons
                        Text(timePeriodItems[index].description)
                            .multilineTextAlignment(.center)
                            .padding()
                            .sheet(isPresented: $isBottomSheetPresented, content: {
                                TimePeriodItemARContent(modelName: sceneName)
                            })
                    }
                    .onAppear(perform: {
                        print("time Period: \(timePeriodEnv.timePeriod)")
                        index = 0
                    })
                    .tint(.black)
                }
                .frame(maxWidth: 450, maxHeight: 420)
                .mask(RoundedRectangle(cornerRadius: 30, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 30, style: .continuous).stroke(lineWidth: 0.5).fill(Color.white))
                .shadow(color: Color.black.opacity(0.3), radius: 20, x: 0, y: 10)
            }
        }
    }
    
    private var timePeriodNavigationButtons: some View {
        HStack(spacing: 30) {
            Button(action: {
                withAnimation{
                    if index > 0 {
                        index -= 1
                    }
                }
            }, label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 30, weight: .bold))
                    .opacity(index == 0 ? 0.3 : 1)
            })
            .disabled(index == 0 ? true : false)
            
            Text(timePeriodItems[index].title)
                .bold()
                .font(timePeriodEnv.timePeriod.timePeriodConfiguration.titleFont)
            
            Button(action: {
                withAnimation{
                    if index < timePeriodItems.count{
                        index += 1
                    }
                }
            }, label: {
                Image(systemName: "chevron.right")
                    .font(.system(size: 30, weight: .bold))
                    .opacity(index == timePeriodItems.count - 1 ? 0.3 : 1)
            })
            .disabled(index == timePeriodItems.count - 1 ? true : false)
        }
    }
}
