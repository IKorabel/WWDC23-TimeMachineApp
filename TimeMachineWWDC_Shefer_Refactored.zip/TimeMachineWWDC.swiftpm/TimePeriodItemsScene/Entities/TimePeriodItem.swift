import SwiftUI

struct TimePeriodItem: Identifiable {
    var title: String
    var description: String
    var id: Int
    var modelIdentifier: String
}
