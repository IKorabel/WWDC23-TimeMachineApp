import SwiftUI

@MainActor class TimePeriodEnvironment: ObservableObject {
    @Published var timePeriod: TimePeriod = .twothousands
}
