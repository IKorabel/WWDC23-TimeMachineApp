import SwiftUI

@main
struct MyApp: App {
    @StateObject var timePeriodEnvironment = TimePeriodEnvironment()
    @StateObject var soundManager = SoundManager.shared
    
    var body: some Scene {
        WindowGroup {
            MainSceneView()
                .environmentObject(timePeriodEnvironment)
                .environmentObject(soundManager)
                .environment(\.colorScheme, .light)
        }
    }
}

struct MainSceneView: View {
    
    var body: some View {
        TabView {
            TimeMaschineSceneView()
                .tabItem { 
                    Image(systemName: "timer")
                    Text("Time Maschine")
                }
                
            TimePeriodPlayerContent()
                .tabItem { 
                    Image(systemName: "music.note")
                    Text("Music room")
                }
            TimePeriodItemsSceneView()
                .tabItem { 
                    Image(systemName: "timelapse")
                    Text("Items")
                }
            CharactersSceneView()
                .tabItem { 
                    Image(systemName: "person.2.fill")
                    Text("People")
                }
        }
    }
}

struct MainSceneView_Previews: PreviewProvider {
    
    static var previews: some View {
        MainSceneView()
            .environmentObject(TimePeriodEnvironment())
    }
}
