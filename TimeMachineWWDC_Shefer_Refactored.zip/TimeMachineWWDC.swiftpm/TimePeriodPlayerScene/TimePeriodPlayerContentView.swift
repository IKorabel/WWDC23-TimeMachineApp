import SwiftUI
import SceneKit
import UIKit

struct TimePeriodPlayerContent: View {
    
    @EnvironmentObject var timePeriodEnv: TimePeriodEnvironment
    @EnvironmentObject var soundPlayerManager: SoundManager
    
    @State var selectedIndex = 0
    @State var soundCarrierIdentifier = "Cassette_Tape_Lite.usdz"
    
    var musicItems = [SongSelectionItem(id: 0, genre: "Rock", imageName: "rockACDC", audioName: ""), SongSelectionItem(id: 1, genre: "Hip-hop", imageName: "hipHop80s", audioName: "")]
        
    var body: some View {
        ZStack {
            let timePeriod = timePeriodEnv.timePeriod
            
            GradientBackgroundView(timePeriod: timePeriod)
            VStack {
                Spacer()
                MusicItemSceneView(musicItemIdentifier: $soundCarrierIdentifier)
                    .padding()
                
            }
        }
        .onAppear(perform: {
            soundCarrierIdentifier = timePeriodEnv.timePeriod.playerConfiguration.soundCarrierModelIdentifier
        })
    }
}


struct PlayerContent_Previews: PreviewProvider {
    
    @StateObject static var soundManager = SoundManager()

    static var previews: some View {
        TimePeriodPlayerContent()
            .environmentObject(TimePeriodEnvironment())
            .environmentObject(soundManager)
    }
}

