import SwiftUI


struct SongSelectionItem: Identifiable {
    var id: Int
    var genre: String
    var imageName: String
    var audioName: String 
}
