import SwiftUI
import SwiftUIX

struct SongSelectionGrid: View {
    
    var songSelectionItem: SongSelectionItem
    @State private var isSelected: Bool = false
    
    var body: some View {
        Button(action: {
            self.isSelected.toggle()
            if isSelected {
              SoundManager.shared.playMusic(introductionSoundEffect: "cassetteTape", songName: "Korandrino_-_Stylish_Rock")  
            } else {
                SoundManager.shared.stopMusic()
            }
        }, label: {
            ZStack {
                VisualEffectBlurView(blurStyle: .systemMaterialLight, vibrancyStyle: .none) { 
                    VStack(spacing: 25) {
                        Image(songSelectionItem.imageName)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(5, antialiased: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
                        Text(songSelectionItem.genre)
                            .font(.system(size: 22, weight: .medium))
                            .foregroundColor(.black)
                    }
                    .padding(.all, 20)
                }
                .frame(width: 200, height: 250, alignment: .center)
                .mask(RoundedRectangle(cornerRadius: 15, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
                .overlay(RoundedRectangle(cornerRadius: 15, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/).stroke(lineWidth: 0.5).fill(Color.white))
                .shadow(color: Color.black.opacity(0.3), radius: 20, x: 0, y: 10)
            }
        })
    }
}
