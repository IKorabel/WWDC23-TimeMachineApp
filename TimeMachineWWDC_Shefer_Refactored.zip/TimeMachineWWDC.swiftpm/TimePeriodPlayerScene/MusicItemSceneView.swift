import SwiftUI
import UIKit
import SwiftUIX
import SceneKit

struct MusicItemSceneView: View {
    @Binding var musicItemIdentifier: String
    @State var isPlaying = true
    @EnvironmentObject var soundPlayerManager: SoundManager
    
    var body: some View {
        ZStack { 
            VStack {
                VisualEffectBlurView(blurStyle: .systemMaterialLight, vibrancyStyle: .fill) { 
                    VStack(spacing: 25) {
                        HStack {
                            Text("It's 8D Audio. \n Please wear headphones to immerse yourself in the atmosphere!")
                                .multilineTextAlignment(.center)
                        }
                        CustomSceneView(modelName: musicItemIdentifier, isPlaying: isPlaying)
                    }
                    .padding()
                    .font(.system(size: 30, weight: .bold))
                    .tint(.black)
                }
                .mask(RoundedRectangle(cornerRadius: 15, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
                .overlay(RoundedRectangle(cornerRadius: 15, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/).stroke(lineWidth: 0.5).fill(Color.white))
                .shadow(color: Color.black.opacity(0.3), radius: 20, x: 0, y: 10)
            }
        }
    }
    
    func interactWithPlayer(song: String) {
        if isPlaying {
            soundPlayerManager.playMusic(introductionSoundEffect: "cassetteTape", songName: song)
        } else {
            soundPlayerManager.pause()
        }
    }
    
}
