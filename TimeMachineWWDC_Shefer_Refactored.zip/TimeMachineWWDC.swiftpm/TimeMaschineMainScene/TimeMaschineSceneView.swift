import SwiftUI

struct TimeMaschineSceneView: View {
    @State var timeTransitionActivated = false
    
    @EnvironmentObject var timePeriodEnv: TimePeriodEnvironment
    
    @State private var rotationDegress: Double = 0.0
    @State private var didOpenSheet: Bool = false
    @ObservedObject var observer = Observer()
    
    var body: some View {
        ZStack {
            GradientBackgroundView(timePeriod: timePeriodEnv.timePeriod)
            VStack() {
                let config = timePeriodEnv.timePeriod.timePeriodConfiguration
                
                Menu("Choose Preferred Time") {
                    var filteredAllCases = TimePeriod.allCases.filter({$0 != timePeriodEnv.timePeriod })
                    ForEach(filteredAllCases, id: \.self) { selectedPeriod in
                        Button(selectedPeriod.rawValue, action: {
                            print("action")
                            timeTransitionActivated.toggle()
                            timePeriodEnv.timePeriod = selectedPeriod
                        })
                    }
                }
                .padding()
                .padding(.horizontal)
                .tint(.white)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))

                VStack(spacing: 1) {
                    Text("Welcome to")
                        .font(.system(size: 60, weight: .medium))
                        .foregroundColor(config.fontColor)
                    Text(config.timePeriodYear)
                        .font(config.yearFont)
                        .foregroundColor(config.fontColor)
                }
                
                Image(systemName: config.systemIconName)
                    .font(.system(size: 90, weight: .bold))
                    .foregroundColor(config.fontColor)
                    .rotationEffect(.degrees(rotationDegress))
                    .animation(.easeInOut(duration: 1))
                
            }
            .sheet(isPresented: $didOpenSheet, content: {
                let content = SheetBody(titleText: "Welcome to Time Maschine", descriptionText: "I decided to develop this app to recreate different time periods and immerse the user in it through objects, characters, and music. I hope I succeeded, have a nice time travel", iconToShow: "timer.circle.fill", tintColor: .systemOrange)
                CharacterStorySceneView(content: content)
                    .presentationDetents([.large])
                    .presentationDragIndicator(.visible)
            })
            .onChange(of: timePeriodEnv.timePeriod, perform: { value in
                SoundManager.shared.turnOnBackgroundMusic(song: value.timePeriodMusicTheme)
                timeTransitionActivated.toggle()
            })
            .onChange(of: timeTransitionActivated, perform: { value in
                if value {
                    rotationDegress += 360
                } else {
                    rotationDegress -= 360
                }
            })
            .onAppear(perform: {
                let hasSeenSheet = UserDefaults.standard.bool(forKey: "hasSeenSheet")
                if !hasSeenSheet {
                    didOpenSheet = true
                    UserDefaults.standard.set(true, forKey: "hasSeenSheet")
                }
            })
        }
    }
}
