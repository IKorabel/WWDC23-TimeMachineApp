import ARKit
import SceneKit
import SwiftUI

struct ARView: UIViewRepresentable {
    private var modelName: String
    
    init(modelName: String) {
        self.modelName = modelName
    }
    
    func makeUIView(context: Context) -> ARSCNView {
        let arSceneView = ARSCNView()
        arSceneView.showsStatistics = true
        arSceneView.delegate = context.coordinator
        
        let scene = SCNScene(named: modelName)!
        arSceneView.scene = scene
        
        let configuration = ARWorldTrackingConfiguration()
        arSceneView.session.run(configuration)
        return arSceneView
    }
    
    func updateUIView(_ uiView: ARSCNView, context: Context) {
        
    }
    
    func makeCoordinator() -> ARCoordinator {
        ARCoordinator()
    }
    
    // Coordinator class for ARView
    class ARCoordinator: NSObject, ARSCNViewDelegate {
        func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
            // Find the ARModel node in the scene
            guard let arSceneView = renderer as? ARSCNView,
                  let modelNode = arSceneView.scene.rootNode.childNode(withName: "modelName", recursively: true) else {
                return
            }
            
            // Set the scale of the model
            let scale = SCNVector3(0.25, 0.25, 0.25) // Change the scale as needed
            modelNode.scale = scale
        }
    }
}

