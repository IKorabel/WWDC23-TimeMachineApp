import SwiftUI

struct TimePeriodItemARContent: View {
    var modelName = ""
    
    var body: some View {
        ARView(modelName: modelName)
    }
}
