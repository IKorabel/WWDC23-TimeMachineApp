import SwiftUI

struct GlassMorphicView: View {
    var body: some View {
       let width = UIScreen.main.bounds.width
        ZStack {
            RoundedRectangle(cornerRadius: 25)
                .fill(.white)
                .opacity(0.1)
                .background(
                    Color.white
                        .opacity(0.8)
                        .blur(radius: 10)
                )
                .shadow(color: .black.opacity(0.1), radius: 5, x: -5, y: -5)
                .shadow(color: /*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/.opacity(0.1), radius: 5, x: 5, y: 5)
        }
        .frame(width: width, height: 270)
    }
}
