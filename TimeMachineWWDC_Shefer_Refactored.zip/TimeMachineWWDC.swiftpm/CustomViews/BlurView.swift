import SwiftUI


struct BlurBackgroundView: UIViewRepresentable {
    
    func makeUIView(context: Context) -> UIVisualEffectView {
        let view = UIVisualEffectView()
        return view
    }
    func updateUIView(_ uiView: UIViewType, context: Context) {}
}
