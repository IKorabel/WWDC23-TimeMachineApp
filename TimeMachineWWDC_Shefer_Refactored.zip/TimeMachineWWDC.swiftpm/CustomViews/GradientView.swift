import SwiftUI

struct GradientBackgroundView: View {
    var timePeriod: TimePeriod
    
    var body: some View {
        let gradientColors = timePeriod.timePeriodConfiguration.gradientColors
        LinearGradient(colors: gradientColors, startPoint: .topLeading, endPoint: .bottomTrailing)
        Circle()
            .frame(width: 300)
            .foregroundColor(Color.blue.opacity(0.3))
            .blur(radius: 10)
            .offset(x: -100, y: -150)
        
        RoundedRectangle(cornerRadius: 30, style: .continuous)
            .frame(width: 500, height: 500)
            .foregroundStyle(LinearGradient(colors: [Color.purple.opacity(0.6), Color.mint.opacity(0.5)], startPoint: .top, endPoint: .leading))
            .offset(x: 300)
            .blur(radius: 30)
            .rotationEffect(.degrees(30))
        
        Circle()
            .frame(width: 450)
            .foregroundStyle(Color.pink.opacity(0.6))
            .blur(radius: 20)
            .offset(x: 200, y: -200)
    }
}
