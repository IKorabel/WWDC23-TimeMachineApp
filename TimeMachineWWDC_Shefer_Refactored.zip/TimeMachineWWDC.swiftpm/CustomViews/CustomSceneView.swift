import SwiftUI
import UIKit
import SceneKit

struct CustomSceneView: UIViewRepresentable {
    var modelName: String
    
    var isPlaying: Bool?
    
    
    func makeUIView(context: Context) -> SCNView {
        let view = SCNView()
        view.allowsCameraControl = true
        view.autoenablesDefaultLighting = true
        view.antialiasingMode = .multisampling2X
        view.backgroundColor = .clear
        guard let sceneView = SCNScene(named: modelName) else { return view }
        sceneView.rootNode.position = SCNVector3(x: 0, y: 0, z: 0)
        view.scene = sceneView
        print("make uiview modelName: \(modelName)")
        return view
    }
    
    func updateUIView(_ uiView: SCNView, context: Context) {
        uiView.scene = SCNScene(named: modelName)
        print("UpdateModelName: \(uiView.scene)")
        guard let isPlaying,
        let sceneView = uiView.scene
        else { return }
        if isPlaying {
            sceneView.rootNode.removeAction(forKey: "rotation")
            let rotation = SCNAction.rotateBy(x: 0, y: CGFloat(Float.pi), z: 0, duration: 1.5)
            let repeatForever = SCNAction.repeatForever(rotation)
            sceneView.rootNode.runAction(repeatForever, forKey: "rotation")
        } else {
            sceneView.rootNode.removeAction(forKey: "rotation")
            let resetRotation = SCNAction.rotateTo(x: 0, y: 0, z: 0, duration: 0.1)
            sceneView.rootNode.runAction(resetRotation)
        }
    }
}
