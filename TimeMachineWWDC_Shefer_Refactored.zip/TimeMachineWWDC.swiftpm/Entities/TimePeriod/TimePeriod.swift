import SwiftUI

enum TimePeriod: String, CaseIterable {
    case sixties = "1960s"
    case eightees = "1980s"
    case twothousands = "2000s"
    
    
    var timePeriodItems: [TimePeriodItem] {
        switch self {
        case .sixties:
            return [TimePeriodItem(title: "Typewriter", description: "The IBM Selectric typewriter was a technological marvel of the 1960s, featuring a 'golf ball' design and advanced features like automatic correction and proportional spacing. Its sleek design and cutting-edge technology made it a favorite among professionals and businesses, and it remains a highly sought-after collector's item today.", id: 1, modelIdentifier: "IBM_Selectric_II_Typewriter.usdz"),
             TimePeriodItem(title: "Vinyl", description: "Vinyl records were a popular way to listen to music. Vinyl records were made from a type of plastic called polyvinyl chloride (PVC) and had grooves that were read by a stylus on a record player. Vinyl records were popular because they had a higher sound quality than previous formats like shellac records, and they were durable and could be played many times without wearing out.", id: 2, modelIdentifier: "VinylRecords.usdz"),
             TimePeriodItem(title: "Lava Lamp", description: "The lava lamp, invented in 1963, quickly became a hit among the counterculture movement. The mesmerizing design consists of a glass container filled with wax and oil, heated by a light bulb at the base. Although banned in some countries in the 1970s due to safety concerns, it remains a beloved symbol of the era today.", id: 0, modelIdentifier: "Groovy_Lava_Lamp.usdz")]
        case .eightees:
            return [TimePeriodItem(title: "Macintosh", description: "The Macintosh was a popular personal computer made by Apple. It had a graphical user interface, which meant you could interact with it using a mouse and icons instead of typing in commands. The Macintosh was known for its user-friendly design and its ability to handle desktop publishing tasks. It played a significant role in the development of the personal computer industry and is still widely used today.", id: 0, modelIdentifier: "Compact_Macintosh.usdz"), 
             TimePeriodItem(title: "Cassette", description: "In the 1980s, people used cassette tapes to listen to music. Cassette tapes were small plastic rectangles with a strip of magnetic tape inside. You could put them in a cassette player and play music. People liked cassette tapes because they were portable, and you could make mixtapes by recording songs from different tapes onto one cassette. However, cassette tapes had some downsides, such as lower sound quality and the risk of the tape getting tangled or damaged.", id: 1, modelIdentifier: "Cassette_Tape_Lite.usdz"), 
                TimePeriodItem(title: "Neon Lights", description: "Neon lights were a popular form of lighting used in signs and advertisements. They were made by filling glass tubes with different gases and passing an electrical current through them, which created a bright, colorful glow. Neon lights were often used to create bold, eye-catching signs and were a popular form of decor in many homes and businesses", id: 2, modelIdentifier: "Love_neon_sign_-_wall.usdz")]
        case .twothousands:
            return [TimePeriodItem(title: "iPhone", description: "The first iPhone was released by Apple in 2007. It was a revolutionary device that combined a phone, music player, and internet browser in one sleek package. The original iPhone had a 3.5-inch touchscreen display and a 2-megapixel camera. It ran on Apple's iOS operating system and came pre-loaded with apps like Safari, Mail, and Maps.", id: 0, modelIdentifier: "Iphone.usdz"), 
              TimePeriodItem(title: "CD", description: "CDs were a popular way to listen to music. CDs, or compact discs, were a type of digital storage media that could hold up to 80 minutes of music. CDs were popular because they had a higher sound quality than previous formats like cassette tapes and were more durable. CD players were also smaller and more portable than previous types of music players, making it easier to listen to music on the go.", id: 1, modelIdentifier: "CD.usdz"), 
                TimePeriodItem(title: "iPhone", description: "The first iPhone was released by Apple in 2007. It was a revolutionary device that combined a phone, music player, and internet browser in one sleek package. The original iPhone had a 3.5-inch touchscreen display and a 2-megapixel camera. It ran on Apple's iOS operating system and came pre-loaded with apps like Safari, Mail, and Maps.", id: 0, modelIdentifier: "Iphone.usdz")]
        }
    }
    
    var playerConfiguration: PlayerConfiguration {
        switch self {
        case .sixties:
            return PlayerConfiguration(soundCarrierModelIdentifier: "VinylRecords.usdz", activationSound: "", songs: [])
        case .eightees:
            return PlayerConfiguration(soundCarrierModelIdentifier: "Cassette_Tape_Lite.usdz", activationSound: "cassetteTape", songs: [])
        case .twothousands:
            return PlayerConfiguration(soundCarrierModelIdentifier: "CD.usdz", activationSound: "cassetteTape", songs: [])
        }
    }
    
    var timePeriodConfiguration: TimePeriodConfiguration {
        switch self {
        case .eightees:
            let colorsForEighteesGradient = [Color.purple, Color.pink]
            
            return TimePeriodConfiguration(playerConfig: playerConfiguration, gradientColors: colorsForEighteesGradient, fontColor: .white, yearFont: .custom("BrushScriptMT", size: 120), titleFont: .custom("BrushScriptMT", relativeTo: .title), systemIconName: "sunrise.fill", timePeriodYear: "1984", modelId: "Cassette_Tape_Lite.usdz") 
        case .sixties:
            let colorsForSixtiesGradient = [Color.orange, Color.yellow]
            return TimePeriodConfiguration(playerConfig: playerConfiguration, gradientColors: colorsForSixtiesGradient, fontColor: .black, 
             yearFont: .custom("Phosphate-Inline", size: 120), titleFont: .custom("Phosphate-Inline", relativeTo: .title), systemIconName: "peacesign", timePeriodYear: "1964", modelId: "VinylRecords.usdz")
        case .twothousands:
            return TimePeriodConfiguration(playerConfig: playerConfiguration, gradientColors: [Color.cyan.opacity(0.7), Color.purple.opacity(0.3)], fontColor: .black, 
             yearFont: .system(size: 100, weight: .bold, design: .rounded), 
               titleFont: .title, systemIconName: "suitcase.rolling.fill", timePeriodYear: "2008", modelId: "VinylRecords.usdz")
        }
    }
     
    var characters: [Character] {
        let timePeriod = self
        return [CharacterOption.martin(timePeriod: timePeriod).character, CharacterOption.paul(timePeriod: timePeriod).character]
    }
    
    var timePeriodMusicTheme: String {
        switch self {
        case .sixties:
            return "60sTheme8dV2"
        case .eightees:
            return "80sTheme8D"
        case .twothousands:
            return ""
        }
    }
}

