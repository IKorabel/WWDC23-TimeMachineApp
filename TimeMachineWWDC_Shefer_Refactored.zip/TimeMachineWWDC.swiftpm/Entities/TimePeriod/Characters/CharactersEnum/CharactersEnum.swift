import SwiftUI

enum CharacterOption {
    case martin(timePeriod: TimePeriod)
    case paul(timePeriod: TimePeriod) 
    
    var character: Character {
        return Character(personalData: personalData, story: buildCharacterStory())
    }
    
    var personalData: CharacterPersonalData {
        switch self {
        case .martin(let timePeriod):
            let name = "Martin Michaels"
            switch timePeriod {
            case .eightees:
                return CharacterPersonalData(name: name, age: "40", photo: "Martin80s")
            case .twothousands:
                return CharacterPersonalData(name: name, age: "64", photo: "Martin2000s")
            case .sixties:
                return CharacterPersonalData(name: name, age: "20", photo: "Martin60s")
            }
        case .paul(let timePeriod):
            let name = "Paul Allen"
            switch timePeriod {
            case .sixties:
                return CharacterPersonalData(name: name, age: "10", photo: "Paul60s")
            case .eightees:
                return CharacterPersonalData(name: name, age: "30", photo: "Paul80s")
            case .twothousands:
                return CharacterPersonalData(name: name, age: "30", photo: "Paul80s")
            }
        }
    }
        
        
        
        func buildCharacterStory() -> CharacterStory {
            switch self {
            case .martin(let timePeriod):
                switch timePeriod {
                case .sixties:
                    return CharacterStory(information: "A 20-year-old native of Louisiana. Martin came from a religious family; his father was a pastor. Contrary to racial discrimination, Martin went to university to study philosophy, but he has a higher goal: to make all people equal. ",
                                   interests: "Martin loves history. Inspired by how some historical figures have changed lives for the better, Martin has only one goal: to have a hand in building a society without racial discrimination",
                                   message: "Hello, friend. The feeling I get is indescribable. I hear from hundreds of supporters of our movement, I talk personally with dozens of members of our movement. We are making history, real history, this is what I dreamed of! However, I realize that a peaceful protest will not help - so we will have to take a radical step. Tonight, we will make history!")
                case .eightees:
                    return CharacterStory(information: "A 40-year-old businessman from Miami. Martin was a famous activist against racial discrimination in the 60s, but now he has moved to Miami and opened several beach bars",
                                          interests: "Martin is a versatile individual. He stands out for his well-developed erudition. But also, after moving to Miami, Martin became interested in running a business, he liked how, working in the bar, he saw the grateful smiles of the guests, and some of them he even helped with psychological problems",
                                          message: "Hey there, my friend! You won't believe it, but after that letter in '64, things didn't go as planned at that protest. Provocateurs showed up, and there were clashes with protesters. I ended up getting arrested. It made me realize that I needed to find other ways to achieve my goals. Instead of tearing things down, I realized I could help people by creating and giving something to them. That way, I could get support and funds for what really interests me. \n That's why I moved to Miami, got a job at a bar, and I was so passionate about it that I decided to open my own bar. Things are going well now, my friend!")
                case .twothousands:
                    return CharacterStory(information: "A 64-year-old entrepreneur, philanthropist, and successful investor from New York City.  Martin Michael is an active philanthropist and has created a scholarship fund covering tuition costs for low-income families.",
                                          interests: "Martin collects and buys various 19th century paintings and other everyday objects. Martin pays great attention to his family and often spends time with his grandchildren",
                                          message: "Greetings. It's been 20 years and we're back in touch.  After 1984, everything was going well, we were opening bar after bar, restaurant after restaurant - I was even called the restaurant king of Miami. As you remember, there was the dot-com bubble, and Apple stock had plummeted to a low. But I even made money on it, because then I bought Apple stock when I heard Jobs was coming back. I like what I do - it's great to see those kids from poor neighborhoods going to the best universities because of our grants.")
                }
            case .paul(let timePeriod):
                switch timePeriod {
                case .sixties:
                    return CharacterStory(information: "A 10-year-old boy living in the small town of Hemsfield. Despite his age, Paul Allen has achieved unprecedented success. This year he became a winner of the International Mathematical Olympiad. His family is a model - his father and mother are honorary researchers who have received a number of awards. Here he is - a true man who has a passion since childhood. Our future!", 
                                          interests: "it seems that Paul Allen loves technical sciences and would love to devote his life to science, but the boy is more passionate about confectionery - he likes this, but he is not allowed to do it",
                                          message: "Hey buddy, I'm feeling down. My parents make me do things I hate and I just want to bake croissants. They care too much about money and status. I wish I could follow my passion without judging them. I would say that I don’t want to participate in these countless math competitions anymore, but then my father will get angry and take out that sharp ruler ... My wrist still hurts ... I hope that one day I can fulfill my dreams. Thank you for being my friend, it means a lot.")
                case .eightees:
                    return CharacterStory(information: "He is only 30 years old, and he is already a high-ranking employee of an audit company. Expensive cars, the best jackets, beautiful women - the embodiment of the American dream. From a small town kid to wealth, a happy life and a Hollywood smile.", 
                                          interests: "Collecting jackets, exercising regularly, watching videos, becoming better than colleagues in any way, in particular Patrick Bateman", 
                                          message: "Oh, you again. Look, not much has really changed. I failed to defend my interests - that's why I took this path, the path of less resistance. And in addition, my classmates teased me, they did not notice me. And I decided for myself that I would become a big person, but in an area that I hate - but this is an opportunity. Okay, I'm having dinner with a local jerk who tries to copy me, Patrick Bateman, and then I'm flying to London.")
                case .twothousands:
                    return CharacterStory(information: "The famous representative of the Yuppie of those times. Went missing in 1984 after arriving in London.", interests: "Collecting jackets, exercising regularly, watching videos, becoming better than colleagues in any way, in particular Patrick Bateman", message: "Gone for dinner with a colleague, then flying to London. You can contact in 2 weeks")
            }
        }
    }
}
