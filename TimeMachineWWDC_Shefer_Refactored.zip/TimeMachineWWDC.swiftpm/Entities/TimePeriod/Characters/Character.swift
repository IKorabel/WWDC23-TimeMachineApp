import SwiftUI

struct TimePeriodCharacters {
    var characters: [Character]
}

struct Character {
    var personalData: CharacterPersonalData
    var story: CharacterStory
}

struct CharacterPersonalData {
    var name: String
    var age: String
    var photo: String
}

