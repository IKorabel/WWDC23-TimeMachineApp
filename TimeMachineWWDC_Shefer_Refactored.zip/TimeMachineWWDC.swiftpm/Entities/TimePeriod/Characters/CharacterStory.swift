import SwiftUI

struct CharacterStory {
    var information: String
    var interests: String
    var message: String
}

