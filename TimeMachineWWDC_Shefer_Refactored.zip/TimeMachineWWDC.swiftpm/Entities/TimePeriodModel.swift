import SwiftUI
import SpriteKit
import UIKit

struct TimePeriodProps {
    var configuration: TimePeriodConfiguration
    var characters: [Character]
    var items: [TimePeriodItem]
    var musicThemeName: String
    
    init(timePeriod: TimePeriod) {
        self.items = timePeriod.timePeriodItems
        self.configuration = timePeriod.timePeriodConfiguration
        self.characters = timePeriod.characters
        self.musicThemeName = timePeriod.timePeriodMusicTheme
    }
}

