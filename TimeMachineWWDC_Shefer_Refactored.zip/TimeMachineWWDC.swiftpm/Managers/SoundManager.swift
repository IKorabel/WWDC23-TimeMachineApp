import SwiftUI
import UIKit
import Combine
import AVKit

class SoundManager: NSObject, ObservableObject, AVAudioPlayerDelegate {
    static let shared = SoundManager()
    private var player: AVAudioPlayer?
    
    @Published var isPlaying: Bool = false
    
    func turnOnBackgroundMusic(song: String) {
        guard let audioFile = Bundle.main.path(forResource: song, ofType: ".mp3") else { return }
        
        let urlForAudio = URL(fileURLWithPath: audioFile)
        
        do {
            isPlaying = true
            player?.delegate = self
            player = try AVAudioPlayer(contentsOf: urlForAudio)
            player?.prepareToPlay()
            player?.play()
        } catch let error {
            print("PlayError: \(error.localizedDescription)")
        }
    }
    
    func playMusic(introductionSoundEffect: String, songName: String) {
        turnOnBackgroundMusic(song: introductionSoundEffect)
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            self.stopMusic()
            self.player?.numberOfLoops = -1
            self.turnOnBackgroundMusic(song: songName)
        }
    }
    
    func pause() {
        player?.pause()
    }
    
    func stopMusic() {
        player = nil
        isPlaying = false
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        isPlaying = false
    }
}
